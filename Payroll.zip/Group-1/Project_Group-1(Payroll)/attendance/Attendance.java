package attendance;

import java.lang.*;

public class Attendance{

	private String month;
	private int fullDaysOnleave;
	private int halfDaysOnleave;
	private final int OfficialLeave=2; 
	
	private double hours;
	private double overTime;
	
	public Attendance(){
		System.out.println("Attendance Constructor");
	}
	
	//take attendance for full-time employee
	public Attendance(String month, int FullDays,int HalfDays){
		this.month=month;
		this.fullDaysOnleave=FullDays;
		this.halfDaysOnleave=HalfDays;
	}
	
	//take attendance for part-time employee
	public Attendance(String month, double hours,double overTime){
		this.month=month;
		this.hours=hours;
		this.overTime=overTime;
	}
	//set methods
	public void setMonth (String month){
		this.month=month;
	}
	
	public 	void setFullDaysOnleave (int FullDaysOnleave){
			this.fullDaysOnleave=fullDaysOnleave;
	}
	public 	void setHalfDaysOnleave (int HalfDaysOnleave){
		this.halfDaysOnleave=halfDaysOnleave;
	}
	
	public 	void setHours(double hours){
		this.hours=hours;
	}
	public 	void setOverTime(double overTime){
		this.overTime=overTime;
	}
	//get methods
	public 	String getMonth(){
		return month;
	}
	public 	int getFullDaysOnleave (){
		return fullDaysOnleave;
	}
	public 	int getHalfDaysOnleave (){
		return halfDaysOnleave;
	}
	public 	double getHours(){
		return hours;
	}
	public 	double  getOverTime(){
		return overTime;
	}
	public 	double getTotalDaysOnLeave(){
		return fullDaysOnleave+(halfDaysOnleave/2.0);
		
	}
	public 	int getOfficialLeave(){
		return OfficialLeave;
	}
	public 	double getPresentDays(){
		return 22-getTotalDaysOnLeave();
	}
	public 	double getPresentHours(){
		return hours+overTime;
	}
	
}