package interfaces;

import java.lang.*;

public interface ILogin{
	public abstract void welcome();
	public abstract void systemLogin();
	public abstract void sleep(String message, int sec);
}