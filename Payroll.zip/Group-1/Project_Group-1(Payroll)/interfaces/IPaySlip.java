package interfaces;
import java.lang.*;


public interface IPaySlip{
	
	public abstract	void paySlip();
	
	
}