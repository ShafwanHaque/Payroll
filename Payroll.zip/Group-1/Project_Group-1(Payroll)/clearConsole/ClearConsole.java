package clearConsole;

import java.io.*;

public class ClearConsole 
{
    public void clearConsole() 
    {
        try 
        {  
            ProcessBuilder pb = new ProcessBuilder("cmd", "/c", "cls"); //Clearing a new cmd process to execute "CLS" command
            pb.inheritIO(); //Allowing the new process to use IO of the current java process
            Process process = pb.start(); //Starting the process
            process.waitFor(); //Waitingfor the process to be completed
        } 
        catch (InterruptedException ex) 
        {
            System.err.println(ex);
        } 
        catch (IOException ex) 
        {
            System.err.println(ex);
        }
    }
}