package fileReadWriteId;
import java.lang.*;
import java.io.*;
import java.lang.NumberFormatException;


public class FileReadWriteId{
	private File file;				
	private FileWriter writer;		
	private FileReader reader;		
	private BufferedReader bfr;		
	
	
	public void writeInFile(String s) throws IOException{
		try
		{
			file = new File("History.txt");			
			file.createNewFile();					
			writer = new FileWriter(file, true);	
			writer.write("\t\t"+s+"\r"+"\n");				
			writer.flush();							
			writer.close();							
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	
	public void readFromFile() throws IOException{   
		try
		{
			reader = new FileReader(file);			
			bfr = new BufferedReader(reader);		
			String text="", temp;					
			while((temp=bfr.readLine())!=null)		
			{
				text=text+temp+"\n"+"\r";			
			}
			System.out.print(text);   				
			reader.close();							
		}
		catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	
}