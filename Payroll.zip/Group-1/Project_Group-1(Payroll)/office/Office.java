package office;

import employee.*;
import java.lang.*;
import java.io.*; 
import java.lang.NumberFormatException;

public class Office{
	private String officeName; 
	private String officeAddress;
	private String officeType;
	Employee employees[];
	
	public Office(){}
	
	public Office(String officeName, String officeAddress, String officeType,int size){
		this.officeName = officeName;
		this.officeAddress = officeAddress;
		this.officeType = officeType;
		employees=new Employee[size];
	}
	//set method
	public void setOfficeName(String officeName){
		this.officeName = officeName;
	}
	public	void setOfficeAddress(String officeAddress){
		this.officeAddress = officeAddress;
	}
	public	void setOfficeType(String officeType){
		this.officeType = officeType;
	}
	//get method
	public	String getOfficeName(){
		return officeName;
	}
	public	String getOfficeAddress (){
		return officeAddress;
	}
	public	String getOfficeType(){
		return officeType;
	}
	
	//calculating total employee
	public int getTotalEmployee(){
		int totalEmployee=0;
		for(int i = 0; i < employees.length; i++){
			if(employees[i] != null){
				totalEmployee+=1;
			}
		}
		return totalEmployee;
	}
	
	//calculating total full-time employee
	public int getTotalFullTimeEmployees(){
		int totalFullTimeEmployees=0;
		for(int i = 0; i < employees.length; i++){
			if(employees[i] != null && employees[i].getType().equals("Full-time")){
				totalFullTimeEmployees+=1;
			}
		}
		return totalFullTimeEmployees;
	}
	
	//calculating total part-time employee
	public int getTotalPartTimeEmployees(){
		int totalPartTimeEmployees=0;
		for(int i = 0; i < employees.length; i++){
			if(employees[i] != null && employees[i].getType().equals("Part-time")){
				totalPartTimeEmployees+=1;
			}
		}
		return totalPartTimeEmployees;
	
	}

	//to add employee
	public	void addEmployee(Employee em){
		int count=0; 
		for(int i=0; i<employees.length; i++) {
			
			if(employees[i] == null) {
				employees[i] = em;
				count =1;
				break;
			}
		}
		if(count==1){
			System.out.println("\t\tEmployee Added");
		}
		else System.out.println("\t\tEmployee Not Added");
	}

	
	//to remove employee
	public	void removeEmployee(Employee em){
		int count=0; 
		for(int i = 0; i < employees.length; i++) {
			if(employees[i] == em) {
				employees[i] = null;
				count+=1;
				break;
			}
		}
		if(count==1){
			System.out.println("\t\tEmployee Removed");
		}
		else System.out.println("\t\tEmployee Not Removed");
	}
	
	
	public void showEmployeeList(){
		int count=1;
		System.out.println();
		System.out.println("\t\tEmployee List");
		System.out.println("\t\tTotal Employee:"+getTotalEmployee());
		for(int i = 0; i <employees.length; i++) {
			if(employees[i] != null){
				System.out.println("\t\t"+count);
				System.out.println("\t\tEmployee Id : "+employees[i].getId());
				System.out.println("\t\tEmployee Name : "+employees[i].getFirstName()+" "+employees[i].getLastName());
				count++;
				}
		}
		}
	
	public void showFullTimeEmployeeList(){
		int count=1;
		System.out.println();
		System.out.println("\t\tFull Time Employee List");
		System.out.println("\t\tTotal Full Time Employee:"+getTotalFullTimeEmployees());
		for(int i = 0; i <employees.length; i++) {
			if(employees[i] != null && employees[i].getType().equals("Full-time")){
				System.out.println("\t\t"+count);
				System.out.println("\t\tEmployee Id : "+employees[i].getId());
				System.out.println("\t\tEmployee Name : "+employees[i].getFirstName()+" "+employees[i].getLastName());
				count++;
				}
		}
	}
	
	public void showPartTimeEmployeeList(){
		int count=1;
		System.out.println();
		System.out.println("\t\tPart Time Employee List");
		System.out.println("\t\tTotal Part Time Employee:"+getTotalPartTimeEmployees());
		for(int i = 0; i < this.employees.length; i++) {
			if(this.employees[i] != null && employees[i].getType().equals("Part-time")){
				System.out.println("\t\t"+count);
				System.out.println("\t\tEmployee Id : "+employees[i].getId()+"   ");
				System.out.println("\t\tEmployee Name : "+employees[i].getFirstName()+" "+employees[i].getLastName());
				count++;
			}
		}
	}
	
	public void employeeDetails(int empId){
		boolean flag = false;
		for(int i = 0; i < employees.length; i++) {
			if(employees[i] != null && employees[i].getId() == empId) {
				employees[i].employeeDetails();
				flag = true;
				break;
			}
		}
		if(flag == false) {
			
			System.out.println("\t\tInvalid Id! Please Try Again.");
		}
	}
	public	void displayNumber(){
		System.out.println();
		System.out.println("\t\tEmployee Number:\n");
		System.out.println("\t\tFull Time:"+getTotalFullTimeEmployees());
		System.out.println("\t\tPart Tiime:"+getTotalPartTimeEmployees());
		System.out.println("\t\tTotal Employee:"+getTotalEmployee());
	}
	
	public	void showAttendence(int empId){
		boolean flag = false;
		for(int i = 0; i < employees.length; i++) {
			if(employees[i] != null && employees[i].getId() == empId) {
				employees[i].displayAttendance();
				flag = true;
				break;
			}
		}
		if(flag == false) {
			
			System.out.println("\t\tInvalid Id! Please Try Again.");
		}
	}
	
	
	public 	void printPaySlip(int empId){
		boolean flag = false;
		for(int i = 0; i < employees.length; i++) {
			
			if(employees[i] != null && employees[i].getId() == empId) {
		System.out.println();	
		System.out.println("\t\t\t\tPay Slip");
		System.out.println("\t\tOffice Name:"+officeName);
		System.out.println("\t\tOffice Address:"+officeAddress);
		System.out.println("\t\tOffice Type:"+officeType);
				employees[i].paySlip();
		System.out.println("\t\tSignature of Employee:____________________");
		System.out.println("\t\tSignature of Director:____________________");
				flag = true;
				break;
			}
		}
		if(flag == false) {
			
			System.out.println("\t\tInvalid Id! Please Try Again.");
		}
	}
}