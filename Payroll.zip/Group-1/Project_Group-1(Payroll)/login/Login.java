package login;

import interfaces.*;
import java.util.Scanner;

import java.lang.*;

public class Login implements ILogin{
	public Login(){}
	
	public void welcome(){
	System.out.println();		
	System.out.println("\t\t****Welcome to Payroll Management System****");
	System.out.println();

	}
	
	
	
	public void systemLogin(){
	Scanner scan = new Scanner(System.in);
	{System.out.println("\t\t****Press Enter to Continue This System****");
	scan.nextLine();
	}
	System.out.println();
	
	int count = 0;
         while (count <= 1) 
            {
                Scanner input = new Scanner(System.in);

                String username;
                String password;

                System.out.print("\t\tEnter Username: ");
				
                username = input.next();

                System.out.print("\t\tEnter Password: ");
				
                password = input.next();
                if ("admin".equals(username) && "admin".equals(password)) 
                {
                    System.out.println("\t\tUser successfully logged-in. ");
					 System.out.println();
					 
                } 
                else 
                {
                    System.out.println("\t\tSorry! You Enter Invalid Username or Password. Please Try again");
                    System.exit(0);
                }
                count++;
                break;

            }	
	}
	
	
	public void sleep(String message, int sec)
 
    {
        int timeToWait = 1;
        System.out.print("\t\t\t\tPlease Wait.");
        try {
            for (int i = 0; i < timeToWait; i++) {
                Thread.sleep(500);
                System.out.print(".");
            }
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
        }
		System.out.println("");
		
    }
}