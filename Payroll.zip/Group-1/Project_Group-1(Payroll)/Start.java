import attendance.*;
import employee.*;
import office.*;
import interfaces.*;
import login.*;
import  fileReadWriteId.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.lang.*;
import clearConsole.*;
import java.io.IOException;
import java.util.Scanner;

public class Start{
	public static void main(String args[]){
	
		Login logIn= new Login();
		logIn.welcome();
		logIn.systemLogin();
		logIn.sleep(null,0); 
		
		FileReadWriteId frwd = new FileReadWriteId();
		Office office = new Office("AMS","Feni","IT",10);
		
		System.out.println("\t\tHistory\n");
		
		
		//add full-time employee
		Employee fe1=new FullTimeEmployee("Shafwanul", "Haque", 1233, "Full-time","Senior officer", "HR", "12-02-2009","05-11-1985", "01723498123", "Feni", "Haque@gmail.com", "Male", 50000);
		office.addEmployee(fe1);
		Attendance attendance1 = new Attendance("July",2,5); // month, full days on leave , half days on leave 
		fe1.insertAttendance(attendance1);
		
		
		Employee fe2=new FullTimeEmployee("Jariatun", "Islam", 1234, "Full-time","Senior Developer", "Developer Team", "12-02-2009","05-11-1985", "01723498124", "Cumilla", "jariatun@gmail.com", "Female",80000);	
		office.addEmployee(fe2);
		Attendance attendance2 = new Attendance("July",2,1); // month, full days on leave , half days on leave 
		fe2.insertAttendance(attendance2);
		fe2.setAdvance(2000);
		
		Attendance attendance6 = new Attendance("July",1,1);
		
		Employee fe3=new FullTimeEmployee("Yuki", "Haque", 1235, "Full-time","Manager", "Finance", "12-02-2009","05-11-1985", "01723498128", "Feni", "yuki@gmail.com", "Female",25000); 
		office.addEmployee(fe3);
		fe3.insertAttendance(attendance6);		// month, full days on leave , half days on leave 
		fe3.setCompanyLoan(15000);
		
		
		
		//add part-time employee
		Employee pe1=new PartTimeEmployee("Ikram", "Hossain", 2235,  "Part-time","Junior officer", "HR","12-02-2009", "05-11-1985", "01723498126", "Feni", "ikram@gmail.com", "Male");
		office.addEmployee(pe1);
		Attendance attendance3 = new Attendance("July",80.0,10.5); // month, actual hours, overtime 
		pe1.insertAttendance(attendance3); 
		
		Employee pe2=new PartTimeEmployee("Lamia", "Akter",2236,"Part-time","junior officer", "HR","12-02-2009", "05-11-1985", "01723498125", "Feni", "Lamia@gmail.com", "Female");
		office.addEmployee(pe2);
		Attendance attendance4 = new Attendance("July",70.0,0.0);	// month, actual hours, overtime 
		pe2.insertAttendance(attendance4);
		
		Employee pe3=new PartTimeEmployee("Hossain", "Mensia",2237,"Part-time","junior officer", "HR","12-02-2009", "05-11-1985", "01723498124", "Feni", "hossain@gmail.com", "Male");
		office.addEmployee(pe3);
		Attendance attendance5 = new Attendance("July",20,2.0);	// month, actual hours, overtime 
		pe3.insertAttendance(attendance5);
		office.removeEmployee(pe3);//to remove the employee
		
		
		Scanner input = new Scanner(System.in);
		
		boolean userWantsToContinue = true;
        do
        { 		Scanner scan = new Scanner(System.in);
           {
               System.out.print("\n\n\n\t\t****Press Enter To Continue This System****\n\n\n");
               scan.nextLine();
           }
           {
               ClearConsole clsconsole = new ClearConsole();
               clsconsole.clearConsole();
           }
           {
               logIn.sleep(null, 0);
           }



			System.out.println();
			System.out.println("\t\t\t----------------------------------");
			System.out.println("\t\t\t****PAYROLL MANAGEMENT  SYSTEM****");
			System.out.println("\t\t\t----------------------------------");
			System.out.println();
			
			System.out.println("\t\t-------------------------------------------------------");
			
			System.out.println("\t\t|Enter-1	To See Employee List                  |");
			System.out.println("\t\t|Enter-2	To See the Full-time Employee List    |");
			System.out.println("\t\t|Enter-3	To See the Part-time Employee List    |");
			System.out.println("\t\t|Enter-4	To See the Details of Employee        |");
			System.out.println("\t\t|Enter-5	To See Employee Attendance            |");
			System.out.println("\t\t|Enter-6	To See Number of Employee             |");
			System.out.println("\t\t|Enter-7	To Print PaySlip of Employee          |");
			System.out.println("\t\t|Enter-8	To Add Id to Read & Write File        |");
			System.out.println("\t\t|Enter-9	To Print Id from Read & Write  File   |");
			System.out.println("\t\t|Enter-0 	To Exit The System                    |");
			System.out.println("\t\t-------------------------------------------------------");
			System.out.println();
			
			System.out.print("\t\tPlease choose one option: ");
			int choice;
			try{
				choice = Integer.parseInt(input.nextLine());
				switch(choice){
					
				case 1: office.showEmployeeList();
                break;
                
                case 2: office.showFullTimeEmployeeList();
				break;

                case 3: office.showPartTimeEmployeeList();
				break;

                case 4: System.out.print("\t\tPlease Enter Employee Id : ");
						try {
								int id = Integer.parseInt(input.nextLine());
								office.employeeDetails(id);
						}
						catch(NumberFormatException e) {
								System.out.println("\t\tSorry! You Enter Wrong key! Please try again.");
						}
						
				break;
				
				case 5: System.out.print("\t\tPlease Enter Employee Id : ");
						try{
								int id = Integer.parseInt(input.nextLine());
								office.showAttendence(id);
						}
						catch(NumberFormatException e) {
								System.out.println("\t\tSorry! You Enter Wrong Key! Please try again.");
						}
							
						
						
                break;
				
				case 6: office.displayNumber();
				break;

                case 7: System.out.print("\t\tPlease Enter Employee Id : ");
						try{
								int id = Integer.parseInt(input.nextLine());
								office.printPaySlip(id);
				
						}
						catch(NumberFormatException e) {
								System.out.println("\t\tSorry! You Enter Wrong Key! Please try again.");
						}
						
						
						
                break;
				
				case 8:	try{
							System.out.print("\t\tPlease Enter Employee Id : ");
							frwd.writeInFile(input.nextLine());
						}
						catch(IOException e) {
							e.printStackTrace();
						}
				break;
				
				case 9: try{
							try{frwd.readFromFile();}
							catch(NullPointerException e){
								frwd.writeInFile("");
								frwd.readFromFile();								
							}
						}
						catch(IOException e){
							e.printStackTrace();
						}

				break;
				
                case 0:  System.exit(0);
				
				default: System.out.println("\t\tSorry! You Enter a Wrong Digit. Please Try Again.");
				} 
			} 
			catch(NumberFormatException e) {
					System.out.println("\t\tSorry! You Enter a Wrong Key! Please try again.");
			}
		}
		while (userWantsToContinue);
	}
}