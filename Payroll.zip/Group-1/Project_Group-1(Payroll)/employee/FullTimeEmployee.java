package employee;
import attendance.*;

import java.lang.*;

public class FullTimeEmployee extends Employee{
	private double netSalary ;// income 
	private double advance; // withdraw a part of salary before salary issued date  
	private double companyLoan;// loan taken from company
	private final double leaveRate=500;//rate for a day leave  

	public FullTimeEmployee (){}
	public FullTimeEmployee (int netSalary){
		this.netSalary = netSalary;
	}
	
	public FullTimeEmployee (String firstName, String lastName, int id, String type, String jobTitle, String department, String dateOfHired, String dateOfBirth, String contactNumber, String address, String email, String gender,int netSalary){
		super(firstName,lastName,id,type,jobTitle,department,dateOfHired,dateOfBirth,contactNumber,address,email,gender);
		this.netSalary = netSalary;
		
	}
	// set methods
	public void setNetSalary(int netSalary){
		this.netSalary = netSalary;
	}
	public	void setAdvance(int advance){
		this.advance = advance;
	}
	public	void setCompanyLoan(int companyLoan){
		this.companyLoan=companyLoan;
	}
	
	// get Salary calcution methods
	public double getNetSalary(){
		return netSalary;
	}
	//65% of  netSalary
	public	double  getBasicSalary(){
		return 0.65*netSalary;
	
	}
	// 10% of  netSalary
	public	double getMedicalAllowance(){
		return 0.1*netSalary;
		 
	}
	// 15% of  netSalary
	public	double getHouseRent(){
		return 0.15*netSalary;
	}
	// 10% of  netSalary
	public	double getConveyance(){
		return 0.1*netSalary;
	}
	//10% of basicSalary
	public	double getProvidentFund(){
		return 0.1*getBasicSalary();
	}
	// 2% of basic Salary
	public	double getIncomeTax(){
		return  0.02*getBasicSalary();
	}
	public	double getAdvance(){
		return advance;
	}
	
	public	double getCompanyLoan(){
		return companyLoan;
	}
	//(9%ofcompanyLoan+companyLoan)/12&all lones are approved for 1 year  
	public	double getCompanyLoanFee(){
		return ((0.09*getCompanyLoan())+getCompanyLoan())/12;
	}
	public	double getLeaveRate(){
		return leaveRate;
	}
	public	double getLeaveDaysFine(){
		double a=0;
		if(attendance.getTotalDaysOnLeave()>attendance.getOfficialLeave()){
		a =(attendance.getTotalDaysOnLeave()-attendance.getOfficialLeave())*leaveRate;
		}
		return a;
	}
	
	// Total Salary calculation
	
	
	public 	double calGrossIncome(){
		double a= getBasicSalary()+getMedicalAllowance()+ getHouseRent()+ getConveyance();
			return a;
	}
	
	public 	double  calFullExpenditure(){
		double fullExpenditure=getProvidentFund()+getIncomeTax()+getAdvance()+getCompanyLoanFee();
		if(attendance.getTotalDaysOnLeave()>attendance.getOfficialLeave()){
			double a =(attendance.getTotalDaysOnLeave()-attendance.getOfficialLeave())*leaveRate;
			
			fullExpenditure+=a;
		}
		return fullExpenditure;
	}
	public 	double calFullSalary(){
		return calGrossIncome()-calFullExpenditure();
	}


	public 	 double calHourSalary(){
		return 0;
	}
	public 	 double calOverSalary(){
		return 0;
	}
	public 	 double calPartSalary(){
		return 0;}
	public	int getRatePerHour(){
		return 0;
	};
	public	int getRateOvertime(){
		return 0;
	};
}