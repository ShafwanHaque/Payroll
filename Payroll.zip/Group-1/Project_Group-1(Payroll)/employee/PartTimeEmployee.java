package employee;
import attendance.*;

import java.lang.*;

public class PartTimeEmployee extends Employee{
	
	private final int ratePerHour = 125;
	private final int rateOvertime = 100;
	
	//double hourSalary;double overSalary;double partSalary;
	
	public PartTimeEmployee(){}
	
	public PartTimeEmployee(String firstName, String lastName, int id, String type, String jobTitle, String department, String dateOfHired, String dateOfBirth, String contactNumber, String address, String email, String gender)
	{
	super(firstName,lastName,id,type,jobTitle,department,dateOfHired,dateOfBirth,contactNumber,address,email,gender);
	}
	
	public	int getRatePerHour(){  
		return ratePerHour;
	}	
	public	int getRateOvertime(){
		return rateOvertime;
	}
	//Salary Calculation 
	
	public 	double calHourSalary(){
		return ratePerHour*attendance.getHours();
	}
	public 	double calOverSalary(){
		return rateOvertime*attendance.getOverTime();
	}
	public 	double calPartSalary(){
		return  calHourSalary()+calOverSalary();
				
	}
	
	
	public	double getBasicSalary(){return 0;}
	public	double getHouseRent (){return 0;}
	public	double getMedicalAllowance(){return 0;}
	public	double getConveyance (){return 0;}
	public	double getProvidentFund(){return 0;}
	public	double getIncomeTax(){return 0;}
	public	 void setAdvance(int advance){};
	public	void setCompanyLoan(int companyLoan){};
	public	double getAdvance(){return 0;}
	public	double getCompanyLoanFee(){return 0;}
	public	void   setLeaveDaysFine(double leaveDaysFine){}
	public	double getLeaveDaysFine(){return 0;}
	public 	double calFullSalary(){return 0;}
	public 	double calFullExpenditure(){return 0;}
	public 	double calGrossIncome(){return 0;}
}