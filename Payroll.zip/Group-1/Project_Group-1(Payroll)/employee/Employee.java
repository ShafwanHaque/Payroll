package employee;

import office.*;
import attendance.*;
import interfaces.*;

import java.lang.*;

public abstract class Employee implements IPaySlip{
	private String firstName;
	private String lastName;
	private int id;
	private String type;
	private String jobTitle;
	private String department;
	private String dateOfHired;
	private String dateOfBirth;
	private String contactNumber;
	private String address;
	private String email;
	private String gender;
	public Attendance attendance;

	public Employee(){}
	
	public Employee(String firstName,String lastName,int id, String type,String jobTitle,String department,String dateOfHired,String dateOfBirth,String contactNumber,String address,String email,String gender,Attendance attendance){
		
		this.firstName = firstName;
		this.lastName = lastName;
		this.id = id;
		this.type = type;
		this.jobTitle = jobTitle;
		this.department = department;
		this.dateOfHired = dateOfHired;
		this.dateOfBirth = dateOfBirth;
		this.contactNumber = contactNumber;
		this.address = address;
		this.email = email;
		this.gender = gender;
		this.attendance=attendance;
		
	}
		public Employee(String firstName,String lastName,int id, String type,String jobTitle,String department,String dateOfHired,String dateOfBirth,String contactNumber,String address,String email,String gender){
		
		this.firstName = firstName;
		this.lastName = lastName;
		this.id = id;
		this.type = type;
		this.jobTitle = jobTitle;
		this.department = department;
		this.dateOfHired = dateOfHired;
		this.dateOfBirth = dateOfBirth;
		this.contactNumber = contactNumber;
		this.address = address;
		this.email = email;
		this.gender = gender;
	}
	
	//set methods
	public void setFirstName(String firstName){
		this.firstName = firstName;
	}
	public void setLastName(String lastName){
		this.lastName = lastName;
	}
	public	void setId(int id){
		this.id = id;
	}
	public	void setType(String type){
		this.type = type;
	}
	public	void setJobTitle(String jobTitle){
		this.jobTitle = jobTitle;
	}
	public	void setDepartment(String department){
		this.department = department;
	}
	public	void setDateofHired(String dateOfHired){
		this.dateOfHired = dateOfHired;
	}
	public	void setDateOfBirth(String dateOfBirth){
		this.dateOfBirth = dateOfBirth;
	}
	public	void setContactNumber(String contactNumber){
		this.contactNumber = contactNumber;
	}
	public	void setAddress(String address){
		this.address = address;
	}
	public	void setEmail(String email){
		this.email = email;
	}
	public	void setGender(String gender){
		this.gender = gender;
	}

	public	void insertAttendance(Attendance attendance){
		this.attendance=attendance;
		
	}
	// get methods
	public	String getFirstName(){
		return this.firstName;
	}
	public	String getLastName(){
		return this.lastName;
	}
	public	int getId(){
		return this.id;
	}
	public	String getType(){
		return this.type;
	}
	public	String getJobTitle(){
		return this.jobTitle;
	}
	public	String getDepartment(){
		return this.department;
	}
	public	String getDateOfHired(){
		return this.dateOfHired;
	}
	public	String getDateOfBirth(){
		return this.dateOfBirth;
	}
	public	String getContactNumber(){
		return this.contactNumber;
	}
	public	String getAddress(){
		return this.address;
	}
	public	String getEmail(){
		return this.email;
	}
	public	String getGender(){
		return this.gender;
	}
	
	public	Attendance getAttendance(){
		return attendance;
	}
	
	//abstract methods
	
	public	abstract double getBasicSalary();
	public	abstract double getHouseRent ();
	public	abstract double getMedicalAllowance();
	public	abstract double getConveyance();
	public	abstract double getProvidentFund();
	public	abstract double getIncomeTax();
	public	abstract void setAdvance(int advance);
	public	abstract void setCompanyLoan(int companyLoan);
	public	abstract double getAdvance();
	public	abstract double getCompanyLoanFee();
	public	abstract double getLeaveDaysFine();
	public 	abstract double calFullSalary();
	public 	abstract double calFullExpenditure();
	public 	abstract double calGrossIncome();
	public 	abstract double calHourSalary();
	public 	abstract double calOverSalary();
	public 	abstract double calPartSalary();
	public	abstract int getRatePerHour();
	public	abstract int getRateOvertime();
		
		
	//
	public	void displayAttendance(){
		System.out.println();
		System.out.println("\t\tAttendence");
		System.out.println("\t\tMonth:"+attendance.getMonth());
		System.out.println("\t\tEmployee Name : "+firstName+" "+lastName);
		System.out.println("\t\tEmployee Id : "+id);
		System.out.println("\t\tEmployee Type:"+type);
		
		if(type.equals("Full-time")){
		System.out.println("\t\tPresent:"+attendance.getPresentDays()+" days");
		System.out.println("\t\tDays On leave:"+attendance.getTotalDaysOnLeave()+" days");
		}
		else{
		System.out.println("\t\tWorking hours:"+attendance.getHours()+" hours");
		System.out.println("\t\tOver Time:"+attendance.getOverTime()+" hours");
		System.out.println("\t\tEmployee Attendence : "+attendance.getPresentHours()+" hours");
		}
	}
	
	//
	public void employeeDetails(){
		System.out.println();
		System.out.println("\t\tEmployee Details");
		System.out.println("\t\tEmployee First Name : "+firstName);
		System.out.println("\t\tEmployee Last Name : "+lastName);
		System.out.println("\t\tEmployee Id : "+id);
		System.out.println("\t\tEmployee Type : "+type);
		System.out.println("\t\tEmployee Job Title : "+jobTitle);
		System.out.println("\t\tEmployee Department : "+department);
		System.out.println("\t\tEmployee Date of Hired : "+dateOfHired);
		System.out.println("\t\tEmployee Contact Number : "+contactNumber);
		System.out.println("\t\tEmployee Address : "+address);
		System.out.println("\t\tEmployee Email : "+email);
		System.out.println("\t\tEmployee Gender : "+gender);
		
		if(type.equals("Part-time")){
		System.out.println("\t\tHour Rate :"+getRatePerHour()+" Tk");
		System.out.println("\t\tOver Time Rate :"+getRateOvertime()+" Tk");
		}
		else { 
			System.out.println("\t\tTotal Income:"+calGrossIncome()+" Tk");
		}
	}
	
	//
	public void paySlip(){
		System.out.println("\t\tMonthly Payslip:"+attendance.getMonth());
		System.out.println("\t\tEmployee Id:"+id);
		System.out.println("\t\tEmployee Name:"+firstName+" "+lastName);
		System.out.println("\t\tEmployee Type:"+type);
		System.out.println("\t\tEmployee Department:"+department);
		System.out.println("\t\tEmployee Designation:"+jobTitle);
		
		System.out.println("\t\t\t\t****Income****");
		if(type.equals("Full-time")){
			System.out.println("\t\tBasic Salary:"+getBasicSalary());
			System.out.println("\t\tHouse Rent:"+getHouseRent ());
			System.out.println("\t\tMedical Allowance:"+getMedicalAllowance());
			System.out.println("\t\tConveyance:"+getConveyance());
			
			System.out.println("\t\tTotal Income:"+calGrossIncome());
			
			System.out.println("\t\t\t\t****Expenditure****");
			System.out.println("\t\tProvident Fund:"+getProvidentFund());
			System.out.println("\t\tIncome Tax:"+getIncomeTax());
			if(getAdvance()>0){
			System.out.println("\t\tAdvance:"+getAdvance());
			}
			if(getLeaveDaysFine()>0){
			System.out.println("\t\tOn Leave Fine :"+getLeaveDaysFine());
			}
			
			if(getCompanyLoanFee()>0){
			System.out.println("\t\tLoan Fee:"+getCompanyLoanFee());
			}
			System.out.println("\t\tTotal Expenditure:"+calFullExpenditure());
			System.out.println("\t\tNet Salary:"+calFullSalary());
			
		}
		else{
			System.out.println("\t\tBasic Hour Payment:"+calHourSalary());
			System.out.println("\t\tOver Time Payment:"+calOverSalary());
			System.out.println("\t\tNet Salary:"+calPartSalary());
		}	
	}
}
	